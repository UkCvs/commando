#!/bin/sh

if `cat /proc/bus/dreambox | grep -q 'nimtype=DVB-S'`; then	# DM500S
for p in \
	"CI" \
	"E Mid" \
	"East E" \
	"East W" \
	"N West" \
	"NE&C" \
	"Oxford" \
	"S East" \
	"S West" \
	"South" \
	"W Mid" \
	"West" \
	"Yk&Li" \
	"Yorks" \
; do ln -sf "BBC1.raw" "BBC One $p.raw"; done

for p in \
	"Anglia East" \
	"Anglia West" \
	"Border Scotland" \
	"Central East" \
	"Central West" \
	"Channel Isles" \
	"Granada" \
	"London" \
	"Meridian North" \
	"Meridian SE" \
	"Meridian South" \
	"Tyne Tees" \
	"West" \
	"West Country" \
	"Yorkshire East" \
	"Yorkshire West" \
; do ln -sf "ITV.raw" "ITV $p.raw"; done

for p in \
	"Anglia" \
	"Central" \
	"Granada" \
	"London" \
	"Meridian SE" \
	"Tyne Tees" \
	"Wales" \
	"West" \
	"West Country" \
	"Yorkshire" \
; do ln -sf "ITV +1.raw" "ITV +1 $p.raw"; done

for p in \
	"Edinburgh" \
	"Glasgow" \
	"Grampian" \
	"North East" \
	"Scottish East" \
	"Scottish West" \
; do ln -sf "STV.raw" "STV $p.raw"; done
else 
# DM500C icon symlinks
for p in \
	"ALBA" \
	"East East" \
	"East Midlands" \
	"East West" \
	"NE & Cumbria" \
	"North West" \
	"Oxford" \
	"South" \
	"South East" \
	"South West" \
	"West" \
	"West Midlands" \
	"Yorks & Lincs" \
	"Yorkshire" \
; do ln -sf "BBC1.raw" "BBC ONE $p.raw"; done

	ln -sf BBC1.raw "BBC ONE.raw"
	ln -sf STV.raw "STV Glasgow.raw"
	ln -sf ITV.raw "ITV Audio Desc.raw"
	ln -sf "Channel 4.raw" "Channel 4 Audio Desc.raw"
	ln -sf "Channel 5.raw" "Channel 5 Audio Desc.raw"
	ln -sf S4C.raw "S4C Audio Desc.raw"
	ln -sf "ARY Ent.raw" "ARY Digital.raw"
# cable icon renames
	mv -f "BBC One London.raw" "BBC ONE London.raw"
	mv -f "BBC One NI.raw" "BBC ONE NI.raw"
	mv -f "BBC One Scotland.raw" "BBC ONE Scotland.raw"
	mv -f "BBC One Wales.raw" "BBC ONE Wales.raw"
	mv -f "BBC Two England.raw" "BBC TWO.raw"
	mv -f "BBC Two Scotland.raw" "BBC TWO Scotland.raw"
	mv -f "BBC Four.raw" "BBC FOUR.raw"
	mv -f "UTV.raw" "Ulster TV.raw"
	mv -f "ITV2+1.raw" "ITV2 +1.raw"
	mv -f "ITV3+1.raw" "ITV3 +1.raw"
	mv -f "ITV4+1.raw" "ITV4 +1.raw"
	mv -f "ComedyCentral.raw" "Comedy Central.raw"
	mv -f "ComedyCent+1.raw" "Comedy Central +1.raw"
	mv -f "ComedyXtra.raw" "Comedy Central Extra.raw"
	mv -f "DMAX+1.raw" "DMAX + 1.raw"
	mv -f "E4+1.raw" "E4 +1.raw"
	mv -f "More4.raw" "More 4.raw"
	mv -f "More4 +1.raw" "More 4 +1.raw"
	mv -f "E!.raw" "E! Entertainment.raw"
	mv -f "CBS Reality+1.raw" "CBS Reality +1.raw"
	mv -f "horror ch+1.raw" "horror channel +1.raw"
	mv -f "Universal.raw" "Universal Channel.raw"
	mv -f "Universal+1.raw" "Universal Channel +1.raw"
	mv -f "QUEST.raw" "Quest.raw"
	mv -f "QUEST+1.raw" "Quest +1.raw"
	mv -f "True Ent.raw" "True Entertainment.raw"
	mv -f "Challenge+1.raw" "Challenge +1.raw"
	mv -f "Sony TV.raw" "SONY TV.raw"
	mv -f "4seven.raw" "4Seven.raw"
	mv -f "YESTERDAY+1.raw" "YESTERDAY +1.raw"
	mv -f "Eden+1.raw" "Eden +1.raw"
	mv -f "Animal Plnt+1.raw" "Animal Planet +1.raw"
	mv -f "Discovery.raw" "Discovery Channel.raw"
	mv -f "Discovery+1.raw" "Discovery Chan +1.raw"
	mv -f "ID.raw" "I.D..raw"
	mv -f "ID+1.raw" "I.D.+1.raw"
	mv -f "Disc.Science.raw" "Discovery Science.raw"
	mv -f "Disc.Sci+1.raw" "Discovery Science +1.raw"
	mv -f "Disc.Turbo.raw" "Discovery Turbo.raw"
	mv -f "Disc.History.raw" "Discovery History.raw"
	mv -f "Disc.History+1.raw" "Disccovery History +1.raw"
	mv -f "Nat Geo.raw" "National Geographic.raw"
	mv -f "Nat Geo+1hr.raw" "National Geographic+1.raw"
	mv -f "Community.raw" "The Community Channel.raw"
	mv -f "History.raw" "HISTORY.raw"
	mv -f "History +1 hour.raw" "HISTORY +1.raw"
	mv -f "Home+1.raw" "Home +1.raw"
	mv -f "Home&Health+.raw" "Home & Health +1.raw"
	mv -f "GOD Channel.raw" "God Channel.raw"
	mv -f "Sky Arts .raw" "Sky Arts.raw"
	mv -f "KISS.raw" "Kiss.raw"
	mv -f "Smash Hits!.raw" "Smash Hits.raw"
	mv -f "Heat.raw" "heat.raw"
	mv -f "Kerrang!.raw" "Kerrang.raw"
	mv -f "Sky Prem+1.raw" "Sky Premiere 1hr.raw"
	mv -f "Sky Action.raw" "Sky Action&Adventure.raw"
	mv -f "Sky DramaRom.raw" "Sky Drama & Romance.raw"
	mv -f "Sky ScFi-Horror.raw" "Sky ScFi Horror.raw"
	mv -f "TCM.raw" "Turner Classic Movies.raw"
	mv -f "TCM+1.raw" "TCM +1.raw"
	mv -f "BT Sport-ESPN.raw" "BT Sport ESPN.raw"
	mv -f "Sky Sp NewsHQ.raw" "Sky Sports News HQ.raw"
	mv -f "LFCTV.raw" "Liverpool FC TV.raw"
	mv -f "BoxNation.raw" "Box Nation.raw"
	mv -f "MOTORS TV UK.raw" "Motors TV.raw"
	mv -f "CNN.raw" "CNN International.raw"
	mv -f "Euronews.raw" "euronews.raw"
	mv -f "FRANCE Eng.raw" "FRANCE24 (ENGLISH).raw"
	mv -f "Al Jazeera Eng.raw" "Al Jazeera English.raw"
	mv -f "CBBC.raw" "CBBC Channel.raw"
	mv -f "BabyTV.raw" "Baby TV.raw"
	mv -f "Cartoon Netwrk.raw" "Cartoon Network.raw"
	mv -f "CN+1.raw" "Cartoon Network +1.raw"
	mv -f "Nickelodeon+1.raw" "Nick +1.raw"
	mv -f "Nick Jr..raw" "Nick Junior.raw"
	mv -f "Nick Jr. 2.raw" "Nick Jr 2.raw"
	mv -f "Disney XD+1.raw" "Disney XD +1.raw"
	mv -f "Disney Chnl.raw" "Disney Channel.raw"
	mv -f "Disney Chnl+1.raw" "Disney Channel+1.raw"
	mv -f "STAR Plus.raw" "Star Plus.raw"
	mv -f "Sony TV Asia.raw" "SONY TV Asia.raw"
	mv -f "BET_BlackEntTv.raw" "BET.raw"
fi
