#!/bin/sh

# original patch script for 28.2E picon symlinks by LraiZer for C16 Autumn 2016
# heavily modded by PaphosAL for conditional VM Cable picons setup 19 Dec 2016
# updated Fri 23 Dec 2016 for LraiZers' new SNP picon naming format

if `cat /proc/bus/dreambox | grep -q 'nimtype=DVB-S'`; then	# DM500S
for p in \
	"ci" \
	"emid" \
	"easte" \
	"eastw" \
	"nwest" \
	"neandc" \
	"oxford" \
	"seast" \
	"swest" \
	"south" \
	"wmid" \
	"west" \
	"ykandli" \
	"yorks" \
; do ln -sf bbc1.raw bbcone$p.raw; done

for p in \
	"angliaeast" \
	"angliawest" \
	"borderscotland" \
	"centraleast" \
	"centralwest" \
	"channelisles" \
	"granada" \
	"london" \
	"meridiannorth" \
	"meridianse" \
	"meridiansouth" \
	"tynetees" \
	"west" \
	"westcountry" \
	"yorkshireeast" \
	"yorkshirewest" \
; do ln -sf itv.raw itv$p.raw; done

for p in \
	"anglia" \
	"central" \
	"granada" \
	"london" \
	"meridianse" \
	"tynetees" \
	"wales" \
	"west" \
	"westcountry" \
	"yorkshire" \
; do ln -sf "itvplus1.raw" itvplus1$p.raw; done

for p in \
	"edinburgh" \
	"glasgow" \
	"grampian" \
	"northeast" \
	"scottisheast" \
	"scottishwest" \
; do ln -sf stv.raw stv$p.raw; done

ln -sf btsportextra.raw btsportmosaicextra.raw
ln -sf skyspnewshq.raw spnews.raw
rm -f betplus1.raw
rm -f btsportshow.raw
rm -f kixpower.raw
else # DM500C
#icon symlinks
for p in \
	"ad" \
	"easteast" \
	"eastmidlands" \
	"eastwest" \
	"neandcumbria" \
	"northwest" \
	"oxford" \
	"south" \
	"southeast" \
	"southwest" \
	"west" \
	"westmidlands" \
	"yorksandlincs" \
	"yorkshire" \
; do ln -sf bbc1.raw bbcone$p.raw; done

	ln -sf aljazeeraenglish.raw aljazeeraarabic.raw
	ln -sf bbc1.raw bbcone.raw
	ln -sf bbctwo.raw bbctwoad.raw
	ln -sf bbcredbutton.raw bbcredbutton0.raw
	ln -sf btsportextra.raw btsportextra0.raw
	ln -sf channel4.raw channel4audiodesc.raw
	ln -sf channel5.raw channel5audiodesc.raw
	ln -sf itv.raw itvanglia.raw
	ln -sf itv.raw itvaudiodesc.raw
	ln -sf itv.raw itvmeridian.raw
	ln -sf itv.raw itvwest.raw
	ln -sf itv.raw itvyorkshire.raw
	ln -sf franceeng.raw france24english.raw
	ln -sf franceeng.raw france24francais.raw
	ln -sf s4c.raw s4caudiodesc.raw
	ln -sf stv.raw stvedinburgh.raw
	ln -sf stv.raw stvglasgow.raw
	ln -sf utv.raw ulstertv.raw
	ln -sf utv.raw utvplus1.raw
# cable icon renames
	mv -f aljazeeraeng.raw aljazeeraenglish.raw
	mv -f animalplntplus1.raw animalplanetplus1.raw
	mv -f arynews.raw arynewsuk.raw
	mv -f bbctwoengland.raw bbctwo.raw
	mv -f betblackenttv.raw bet.raw
	mv -f cartoonnetwrk.raw cartoonnetwork.raw
	mv -f cbbc.raw cbbcchannel.raw
	mv -f cnplus1.raw cartoonnetworkplus1.raw
	mv -f cnn.raw cnninternational.raw
	mv -f comedycentplus1.raw comedycentralplus1.raw
	mv -f comedyxtra.raw comedycentralextra.raw
	mv -f community.raw thecommunitychannel.raw
	mv -f dischistory.raw discoveryhistory.raw
	mv -f dischistoryplus1.raw discoveryhistoryplus1.raw
	mv -f discscience.raw discoveryscience.raw
	mv -f discsciplus1.raw discoveryscienceplus1.raw
	mv -f discturbo.raw discoveryturbo.raw
	mv -f discovery.raw discoverychannel.raw
	mv -f discoveryplus1.raw discoverychanplus1.raw
	mv -f disneychnl.raw disneychannel.raw
	mv -f disneychnlplus1.raw disneychannelplus1.raw
	mv -f foxnews.raw foxnewschannel
	mv -f ginxesportstv.raw ginx.raw
	mv -f historyplus1hour.raw historyplus1.raw
	mv -f homeandhealthplus.raw homeandhealthplus1.raw
	mv -f horrorchplus1.raw horrorchannelplus1.raw
	mv -f lfctv.raw liverpoolfctv.raw
	mv -f motorstvuk.raw motorstv.raw
	mv -f natgeo.raw nationalgeographic.raw
	mv -f natgeoplus1hr.raw nationalgeographicplus1.raw
	mv -f ndtv24x7.raw ndtvgoodtimes.raw
	mv -f nickjr.raw nickjunior.raw
	mv -f nickjr2.raw nickjr2.raw
	mv -f nickelodeonplus1.raw nickplus1.raw
	mv -f nollywood.raw nollywoodmovies.raw
	mv -f rishtey.raw rishteyeurope.raw
	mv -f rte2.raw rtetwo.raw
	mv -f skyaction.raw skyactionandadventure.raw
	mv -f skydramarom.raw skydramaandromance.raw
	mv -f skypremplus1.raw skypremiere1hr.raw
	mv -f skyspnewshq.raw skysportsnewshq.raw
	mv -f sonytv.raw sonytvasia.raw
	mv -f tcm.raw turnerclassicmovies.raw
	mv -f trueent.raw trueentertainment.raw
	mv -f tv5monde.raw tv5.raw
	mv -f universal.raw universalchannel.raw
	mv -f universalplus1.raw universalchannelplus1.raw
	mv -f .raw .raw
# remove icons for non-existant channels on VM
	rm -f arise*
	rm -f aryqtv*
	rm -f believe*
	rm -f ben*
	rm -f best*
	rm -f capital*
	rm -f cctv*
	rm -f channelaka*
	rm -f chelsea*
	rm -f chstv*
	rm -f cnc*
	rm -f crimeplusinvplus1*
	rm -f ewtn*
	rm -f faith*
	rm -f fashion*
	rm -f foodnetwrkplus1*
	rm -f front*
	rm -f gospel*
	rm -f heart*
	rm -f holiday*
	rm -f horse*
	rm -f inspirationtv*
	rm -f kix*
	rm -f kixplus1*
	rm -f lifetimeplus1*
	rm -f loveworld*
	rm -f mov4*
	rm -f mtvplus1*
	rm -f mtvmusicplus1*
	rm -f mychannel*
	rm -f nmetv*
	rm -f now*
	rm -f olive*
	rm -f pcne*
	rm -f pickplus1*
	rm -f popplus1*
	rm -f prop*
	rm -f revel*
	rm -f rtejr*
	rm -f rtenewsnow*
	rm -f rteoneplus1*
	rm -f russia*
	rm -f showcase*
	rm -f skyatlantic*
	rm -f sky1plus1*
	rm -f sonl*
	rm -f sonychnlplus1*
	rm -f sonymovies*
	rm -f tlcplus2*
	rm -f travelchplus1*
	rm -f trutvplus1*
	rm -f wordnetwork*
	rm -f *
	# nb: more removes to follow with daveraves' new 468 channels picon pack!
	# (Still WIP as @ 24 Dec 2016 onwards...)
fi

# common for sat and cable
ln -sf bbcredbutton.raw bbcredbutton1.raw
for p in 1 2 3 4 5 6 7 8 9; do
	ln -sf skysportsactive.raw skysportsactive$p.raw
done

for p in 1 2 3 4 5 6; do
	ln -sf btsportextra.raw btsportextra$p.raw
done
