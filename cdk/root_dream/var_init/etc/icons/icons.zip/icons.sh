#!/bin/sh

# original patch script for 28.2E picon symlinks by LraiZer for C16 Autumn 2016
# modded by PaphosAL for initial conditional VM Cable picons setup 19 Dec 2016
# updated Fri 23 Dec 2016 for LraiZers' new SNP picon naming format. GENIUS!
# 23-27 Dec 2016: more conditional picons nukes if channel is not on cable
# (using daveraves' new 474 channels picons package)! THANKS Dave! :)
# updated Thu 02 Feb 2017: Sky Box Office removed (as now dead)

if `cat /proc/bus/dreambox | grep -q 'nimtype=DVB-S'`; then	# DM500S
	for p in ci emid easte eastw nwest neandc oxford seast swest south wmid west ykandli yorks; do
		ln -sf bbc1.raw bbcone$p.raw
	done
	for p in angliaeast angliawest borderscotland centraleast centralwest channelisles granada london meridiannorth meridianse meridiansouth tynetees west westcountry yorkshireeast yorkshirewest; do
		ln -sf itv.raw itv$p.raw
	done
	for p in anglia central granada london meridianse tynetees wales west westcountry yorkshire; do
		ln -sf "itvplus1.raw" itvplus1$p.raw
	done
	for p in edinburgh glasgow grampian northeast scottisheast scottishwest; do
		ln -sf stv.raw stv$p.raw
	done
	for p in 1 2 3 4; do
		ln -sf skyanytime.raw skyanytime$p.raw
	done
	ln -sf bbconelondon.raw bbconelon.raw
	ln -sf bbctwoengland.raw bbctwoeng.raw
	ln -sf btsportextra.raw btsportmosaicextra.raw
	ln -sf skyspnewshq.raw spnews.raw
	rm betplus1.* btsportshow.* kixpower.* vm.*
else # DM500C
#icon symlinks
	ln -sf aljazeeraenglish.raw aljazeeraarabic.raw
	for p in ad easteast eastmidlands eastwest neandcumbria northwest oxford south southeast southwest west westmidlands yorksandlincs yorkshire; do
		ln -sf bbc1.raw bbcone$p.raw
	done
	ln -sf bbc1.raw bbcone.raw
	ln -sf bbctwo.raw bbctwoad.raw
	ln -sf bbcredbutton.raw bbcredbutton0.raw
	ln -sf btsportextra.raw btsportextra0.raw
	ln -sf channel4.raw channel4audiodesc.raw
	ln -sf channel5.raw channel5audiodesc.raw
	for p in 24english 24francais; do
		ln -sf franceeng.raw ln -sf france$p.raw
	done
	for p in itvanglia itvaudiodesc itvmeridian itvwest itvyorkshire; do
		ln -sf itv.raw itv$p.raw
	done
	ln -sf s4c.raw s4caudiodesc.raw
	for p in edinburgh glasgow; do
		ln -sf stv.raw stv$p.raw
	done
	for p in ulstertv utvplus1; do
		ln -sf utv.raw $p.raw
	done
	for p in moviemix virginmoviespreview liveeventspreviews skysportsevents; do
		ln -sf vm.raw $p.raw
	done
# cable icon renames
	mv aljazeeraeng.* aljazeeraenglish.raw
	mv animalplntplus1.* animalplanetplus1.raw
	mv arynews.* arynewsuk.raw
	mv bbctwoengland.* bbctwo.raw
	mv betblackenttv.* bet.raw
	mv cartoonnetwrk.* cartoonnetwork.raw
	mv cbbc.* cbbcchannel.raw
	mv cnplus1.* cartoonnetworkplus1.raw
	mv cnn.* cnninternational.raw
	mv comedycentplus1.* comedycentralplus1.raw
	mv comedyxtra.* comedycentralextra.raw
	mv community.* thecommunitychannel.raw
	mv dischistory.* discoveryhistory.raw
	mv dischistoryplus1.* discoveryhistoryplus1.raw
	mv discscience.* discoveryscience.raw
	mv discsciplus1.* discoveryscienceplus1.raw
	mv discturbo.* discoveryturbo.raw
	mv discovery.* discoverychannel.raw
	mv discoveryplus1.* discoverychanplus1.raw
	mv disneychnl.* disneychannel.raw
	mv disneychnlplus1.* disneychannelplus1.raw
	mv foxnews.* foxnewschannel
	mv ginxesportstv.* ginx.raw
	mv historyplus1hour.* historyplus1.raw
	mv homeandhealthplus.* homeandhealthplus1.raw
	mv horrorchplus1.* horrorchannelplus1.raw
	mv lfctv.* liverpoolfctv.raw
	mv motorstvuk.* motorstv.raw
	mv natgeo.* nationalgeographic.raw
	mv natgeoplus1hr.* nationalgeographicplus1.raw
	mv ndtv24x7.* ndtvgoodtimes.raw
	mv nickjr.* nickjunior.raw
	mv nickjr2.* nickjr2.raw
	mv nickelodeonplus1.* nickplus1.raw
	mv nollywood.* nollywoodmovies.raw
	mv rishtey.* rishteyeurope.raw
	mv rte2.* rtetwo.raw
	mv skyaction.* skyactionandadventure.raw
	mv skydramarom.* skydramaandromance.raw
	mv skypremplus1.* skypremiere1hr.raw
	mv skyspnewshq.* skysportsnewshq.raw
	mv sonytv.* sonytvasia.raw
	mv tcm.* turnerclassicmovies.raw
	mv trueent.* trueentertainment.raw
	mv tv5monde.* tv5.raw
	mv universal.* universalchannel.raw
	mv universalplus1.* universalchannelplus1.raw
# remove icons for non-existant channels on VM
	rm 3e* aa* ab* ah* ai* ak* ala* am* aplu* ari* aryq* atn* bel* ben* bes* bl* br*
	rm cap* cc* channelaka* channel44* channeli* chelsea* chi* chstv* cnc*
	rm crimeplusinvplus1* dmp* dun* eir* em* ew* fa* fk* foodnetwrkplus1* front*
	rm geo* gl* gos* gr* he* hid* hig* hil* hoc* hol* horse* idealextra* insp*
	rm iq* ir* isl* itvbo* itve* jml* keep* kic* kix.* kixplus1* ktv*
	rm lifetimeplus1* love* madan* mov4* mta* mtvmusicplus1* mtvplus1* mych*
	rm news18* noor* now* ntv* o* pav* pcne* pea* pickplus1* popplus1* prop*
	rm psy* ptc* ptv* ret* reve* rtej* rten* rteoneplus1* rus* sa* sc* show*
	rm si* skyat* skyany* skybo* sky1plus1* sonl* sonychnlplus1* sonymovies*
	rm starut* 	rm starz* tak* tal* tbn* thed* them* thev* tim* tinypoplus1*
	rm tlcplus2* travelchplus1* tri* truechrstmsplus1* truemoviesplus1* tv3*
	rm trutvplus1* tv99* tvc* tvo* tvw* umm* utvi* vch* ven* voxa* word* your*
fi
# common for sat and cable
ln -sf bbcredbutton.raw bbcredbutton1.raw
for p in 1 2 3 4 5 6; do
	ln -sf btsportextra.raw btsportextra$p.raw
done
ln -sf skydisney.raw skypixar.raw
for p in 1 2 3 4 5 6 7 8 9; do
	ln -sf skysportsactive.raw skysportsactive$p.raw
done
