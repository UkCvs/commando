#!/bin/sh

# original patch script for 28.2E picon symlinks by LraiZer for C16 Autumn 2016
# heavily modded by PaphosAL for conditional VM Cable picons setup 19 Dec 2016

if `cat /proc/bus/dreambox | grep -q 'nimtype=DVB-S'`; then	# DM500S
for p in \
	"CI" \
	"E Mid" \
	"East E" \
	"East W" \
	"N West" \
	"NE&C" \
	"Oxford" \
	"S East" \
	"S West" \
	"South" \
	"W Mid" \
	"West" \
	"Yk&Li" \
	"Yorks" \
; do ln -sf BBC1.raw "BBC One $p.raw"; done

for p in \
	"Anglia East" \
	"Anglia West" \
	"Border Scotland" \
	"Central East" \
	"Central West" \
	"Channel Isles" \
	"Granada" \
	"London" \
	"Meridian North" \
	"Meridian SE" \
	"Meridian South" \
	"Tyne Tees" \
	"West" \
	"West Country" \
	"Yorkshire East" \
	"Yorkshire West" \
; do ln -sf ITV.raw "ITV $p.raw"; done

for p in \
	"Anglia" \
	"Central" \
	"Granada" \
	"London" \
	"Meridian SE" \
	"Tyne Tees" \
	"Wales" \
	"West" \
	"West Country" \
	"Yorkshire" \
; do ln -sf "ITV +1.raw" "ITV +1 $p.raw"; done

for p in \
	"Edinburgh" \
	"Glasgow" \
	"Grampian" \
	"North East" \
	"Scottish East" \
	"Scottish West" \
; do ln -sf STV.raw "STV $p.raw"; done

ln -sf "Sky Sp NewsHQ.raw" "SP News.raw"
rm -f "Kix Power.raw"
rm -f "Sky Disney.raw"
else # DM500C
#icon symlinks
for p in \
	"East East" \
	"East Midlands" \
	"East West" \
	"NE & Cumbria" \
	"North West" \
	"Oxford" \
	"South" \
	"South East" \
	"South West" \
	"West" \
	"West Midlands" \
	"Yorks & Lincs" \
	"Yorkshire" \
; do ln -sf BBC1.raw "BBC ONE $p.raw"; done
	ln -sf BBC1.raw "BBC ONE.raw"
	ln -sf BBC1.raw "BBC ALBA.raw"
	ln -sf "Channel 4.raw" "Channel 4 Audio Desc.raw"
	ln -sf "Channel 5.raw" "Channel 5 Audio Desc.raw"
	ln -sf ITV.raw "ITV Anglia.raw"
	ln -sf ITV.raw "ITV Audio Desc.raw"
	ln -sf ITV.raw "ITV Meridian.raw"
	ln -sf ITV.raw "ITV West.raw"
	ln -sf ITV.raw "ITV Yorkshire.raw"
	ln -sf S4C.raw "S4C Audio Desc.raw"
	ln -sf STV.raw "STV Edinburgh.raw"
	ln -sf STV.raw "STV Glasgow.raw"
	ln -sf UTV.raw "Ulster TV.raw"
	ln -sf UTV.raw "UTV +1.raw"
# cable icon renames
	mv -f 4seven.raw "4Seven.raw"
	mv -f "Al Jazeera Eng.raw" "Al Jazeera English.raw"
	mv -f "Animal Plnt+1.raw" "Animal Planet +1.raw"
	mv -f BabyTV.raw "Baby TV.raw"
	mv -f "BBC Four.raw" "BBC FOUR.raw"
	mv -f "BBC One London.raw" "BBC ONE London.raw"
	mv -f "BBC One NI.raw" "BBC ONE NI.raw"
	mv -f "BBC One Scotland.raw" "BBC ONE Scotland.raw"
	mv -f "BBC One Wales.raw" "BBC ONE Wales.raw"
	mv -f "BBC Two England.raw" "BBC TWO.raw"
	mv -f "BBC Two Scotland.raw" "BBC TWO Scotland.raw"
	mv -f "BBC Two NI.raw" "BBC TWO NI.raw"
	mv -f "BBC Two Wales.raw" "BBC TWO Wales.raw"
	mv -f BoxNation.raw "Box Nation.raw"
	mv -f "BT Sport-ESPN.raw" "BT Sport ESPN.raw"
	mv -f "Cartoon Netwrk.raw" "Cartoon Network.raw"
	mv -f CBBC.raw "CBBC Channel.raw"
	mv -f "CBS Reality+1.raw" "CBS Reality +1.raw"
	mv -f Challenge+1.raw "Challenge +1.raw"
	mv -f CN+1.raw "Cartoon Network +1.raw"
	mv -f CNN.raw "CNN International.raw"
	mv -f ComedyCentral.raw "Comedy Central.raw"
	mv -f ComedyCent+1.raw "Comedy Central +1.raw"
	mv -f ComedyXtra.raw "Comedy Central Extra.raw"
	mv -f Community.raw "The Community Channel.raw"
	mv -f Disc.History.raw "Discovery History.raw"
	mv -f Disc.History+1.raw "Disccovery History +1.raw"
	mv -f Disc.Science.raw "Discovery Science.raw"
	mv -f Disc.Sci+1.raw "Discovery Science +1.raw"
	mv -f Disc.Turbo.raw "Discovery Turbo.raw"
	mv -f Discovery.raw "Discovery Channel.raw"
	mv -f Discovery+1.raw "Discovery Chan +1.raw"
	mv -f "Disney Chnl.raw" "Disney Channel.raw"
	mv -f "Disney Chnl+1.raw" "Disney Channel+1.raw"
	mv -f "Disney XD+1.raw" "Disney XD +1.raw"
	mv -f DMAX+1.raw "DMAX + 1.raw"
	mv -f E!.raw "E! Entertainment.raw"
	mv -f E4+1.raw "E4 +1.raw"
	mv -f Eden+1.raw "Eden +1.raw"
	mv -f Euronews.raw euronews.raw
	mv -f "FRANCE Eng.raw" "FRANCE24 (ENGLISH).raw"
	mv -f "FOX News.raw" "Fox News Channel"
	mv -f GINXeSportsTV.raw GINX.raw
	mv -f "GOD Channel.raw" "God Channel.raw"
	mv -f History.raw HISTORY.raw
	mv -f "History +1 hour.raw" "HISTORY +1.raw"
	mv -f Home+1.raw "Home +1.raw"
	mv -f "Home&Health+.raw" "Home & Health +1.raw"
	mv -f "horror ch+1.raw" "horror channel +1.raw"
	mv -f ID.raw I.D..raw
	mv -f ID+1.raw I.D.+1.raw
	mv -f ITV2+1.raw "ITV2 +1.raw"
	mv -f ITV3+1.raw "ITV3 +1.raw"
	mv -f ITV4+1.raw "ITV4 +1.raw"
	mv -f Kerrang!.raw Kerrang.raw
	mv -f KISS.raw Kiss.raw
	mv -f LFCTV.raw "Liverpool FC TV.raw"
	mv -f More4.raw "More 4.raw"
	mv -f "More4 +1.raw" "More 4 +1.raw"
	mv -f "MOTORS TV UK.raw" "Motors TV.raw"
	mv -f movies4men.raw "Movies 4 Men.raw"
	mv -f "Nat Geo Wild.raw" "Nat Geo WILD.raw"
	mv -f "Nat Geo.raw" "National Geographic.raw"
	mv -f "Nat Geo+1hr.raw" "National Geographic+1.raw"
	mv -f "Nick Jr..raw" "Nick Junior.raw"
	mv -f "Nick Jr. 2.raw" "Nick Jr 2.raw"
	mv -f Nickelodeon+1.raw "Nick +1.raw"
	mv -f Nollywood.raw "Nollywood Movies.raw"
	mv -f QUEST.raw Quest.raw
	mv -f QUEST+1.raw "Quest +1.raw"
	mv -f RT*One.raw "RTE One.raw"
	mv -f RT*2.raw RTE2.raw
	mv -f "Sky Action.raw" "Sky Action&Adventure.raw"
	mv -f "Sky Arts .raw" "Sky Arts.raw"
	mv -f "Sky DramaRom.raw" "Sky Drama & Romance.raw"
	mv -f "Sky Prem+1.raw" "Sky Premiere 1hr.raw"
	mv -f "Sky ScFi-Horror.raw" "Sky ScFi Horror.raw"
	mv -f "Sky Sp NewsHQ.raw" "Sky Sports News HQ.raw"
	mv -f "Smash Hits!.raw" "Smash Hits.raw"
	mv -f "Sony TV.raw" "SONY TV Asia.raw"
	mv -f "STAR Plus.raw" "Star Plus.raw"
	mv -f TCM.raw "Turner Classic Movies.raw"
	mv -f TCM+1.raw "TCM +1.raw"
	mv -f "tru TV.raw" truTV.raw
	mv -f "True Ent.raw" "True Entertainment.raw"
	mv -f Universal.raw "Universal Channel.raw"
	mv -f Universal+1.raw "Universal Channel +1.raw"
	mv -f YESTERDAY+1.raw "YESTERDAY +1.raw"
# remove icons for non-existant channels on VM
	rm -f ARISE*
	rm -f Believe*
	rm -f BEN*
	rm -f Best*
	rm -f CAPITAL*
	rm -f CCTV*
	rm -f "Channel AKA.raw"
	rm -f Chelsea*
	rm -f CHSTV*
	rm -f CNC*
	rm -f "Crime+Inv +1.raw"
	rm -f EWTN*
	rm -f Faith*
	rm -f Fashion*
	rm -f "Food Netwrk+1.raw"
	rm -f Front*
	rm -f Gospel*
	rm -f Heart*
	rm -f holiday*
	rm -f Horse*
	rm -f "Inspiration TV.raw"
	rm -f Kix.raw
	rm -f Kix+1.raw
	rm -f Lifetime+1*
	rm -f LOVEWORLD*
	rm -f mov4*
	rm -f MTV+1*
	rm -f "MTV Music +1.raw"
	rm -f "My Channel.raw"
	rm -f "NME TV.raw"
	rm -f NOW*
	rm -f Olive*
	rm -f PCNE*
	rm -f Pick+1*
	rm -f POP+1*
	rm -f PopGirl*
	rm -f prop*
	rm -f revel*
	rm -f Russia*
	rm -f Showcase*
	rm -f "Sky Atlantic.raw"
	rm -f "Sky Atlantic .raw"
	rm -f "Sky Atlantic+1.raw"
	rm -f "Sky Disney .raw"
	rm -f "Sky1 +1.raw"
	rm -f SkySpBox*
	rm -f SonL*
	rm -f "Sony Chnl +1.raw"
	rm -f "Sony Movies.raw"
	rm -f "Sony Movies+1.raw"
	rm -f TLC+2*
	rm -f "Travel Channel.raw"
	rm -f "Travel Ch +1.raw"
	rm -f "tru TV+1.raw"
	rm -f "Word Network.raw"
fi
