#!/bin/sh

# original patch script for 28.2E picon symlinks by LraiZer for C16 Autumn 2016
# modded by PaphosAL for initial conditional VM Cable picons setup 19 Dec 2016
# updated Fri 23 Dec 2016 for LraiZers' new SNP picon naming format. GENIUS!
# 25 Dec 2016: more updates for conditional picons nukes if channel not on cable
# using daveraves' new 468 channels picons package! THANKS Dave! :)

if `cat /proc/bus/dreambox | grep -q 'nimtype=DVB-S'`; then	# DM500S
for p in \
	"ci" \
	"emid" \
	"easte" \
	"eastw" \
	"nwest" \
	"neandc" \
	"oxford" \
	"seast" \
	"swest" \
	"south" \
	"wmid" \
	"west" \
	"ykandli" \
	"yorks" \
; do ln -sf bbc1.raw bbcone$p.raw; done

for p in \
	"angliaeast" \
	"angliawest" \
	"borderscotland" \
	"centraleast" \
	"centralwest" \
	"channelisles" \
	"granada" \
	"london" \
	"meridiannorth" \
	"meridianse" \
	"meridiansouth" \
	"tynetees" \
	"west" \
	"westcountry" \
	"yorkshireeast" \
	"yorkshirewest" \
; do ln -sf itv.raw itv$p.raw; done

for p in \
	"anglia" \
	"central" \
	"granada" \
	"london" \
	"meridianse" \
	"tynetees" \
	"wales" \
	"west" \
	"westcountry" \
	"yorkshire" \
; do ln -sf "itvplus1.raw" itvplus1$p.raw; done

for p in \
	"edinburgh" \
	"glasgow" \
	"grampian" \
	"northeast" \
	"scottisheast" \
	"scottishwest" \
; do ln -sf stv.raw stv$p.raw; done

for p in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 20; do
	ln -sf skyboxoffice.raw skyboxoffice$p.raw
done

ln -sf btsportextra.raw btsportmosaicextra.raw
ln -sf skyboxoffice.raw skyboxofficereviewir.raw
ln -sf skyboxoffice.raw skyboxofficereviewuk.raw
ln -sf skyspnewshq.raw spnews.raw
rm -f betplus1.raw
rm -f btsportshow.raw
rm -f kixpower.raw
else # DM500C
#icon symlinks
for p in \
	"ad" \
	"easteast" \
	"eastmidlands" \
	"eastwest" \
	"neandcumbria" \
	"northwest" \
	"oxford" \
	"south" \
	"southeast" \
	"southwest" \
	"west" \
	"westmidlands" \
	"yorksandlincs" \
	"yorkshire" \
; do ln -sf bbc1.raw bbcone$p.raw; done

	ln -sf aljazeeraenglish.raw aljazeeraarabic.raw
	ln -sf bbc1.raw bbcone.raw
	ln -sf bbctwo.raw bbctwoad.raw
	ln -sf bbcredbutton.raw bbcredbutton0.raw
	ln -sf btsportextra.raw btsportextra0.raw
	ln -sf channel4.raw channel4audiodesc.raw
	ln -sf channel5.raw channel5audiodesc.raw
	ln -sf itv.raw itvanglia.raw
	ln -sf itv.raw itvaudiodesc.raw
	ln -sf itv.raw itvmeridian.raw
	ln -sf itv.raw itvwest.raw
	ln -sf itv.raw itvyorkshire.raw
	ln -sf franceeng.raw france24english.raw
	ln -sf franceeng.raw france24francais.raw
	ln -sf s4c.raw s4caudiodesc.raw
	ln -sf stv.raw stvedinburgh.raw
	ln -sf stv.raw stvglasgow.raw
	ln -sf utv.raw ulstertv.raw
	ln -sf utv.raw utvplus1.raw
# cable icon renames
	mv -f aljazeeraeng.raw aljazeeraenglish.raw
	mv -f animalplntplus1.raw animalplanetplus1.raw
	mv -f arynews.raw arynewsuk.raw
	mv -f bbctwoengland.raw bbctwo.raw
	mv -f betblackenttv.raw bet.raw
	mv -f cartoonnetwrk.raw cartoonnetwork.raw
	mv -f cbbc.raw cbbcchannel.raw
	mv -f cnplus1.raw cartoonnetworkplus1.raw
	mv -f cnn.raw cnninternational.raw
	mv -f comedycentplus1.raw comedycentralplus1.raw
	mv -f comedyxtra.raw comedycentralextra.raw
	mv -f community.raw thecommunitychannel.raw
	mv -f dischistory.raw discoveryhistory.raw
	mv -f dischistoryplus1.raw discoveryhistoryplus1.raw
	mv -f discscience.raw discoveryscience.raw
	mv -f discsciplus1.raw discoveryscienceplus1.raw
	mv -f discturbo.raw discoveryturbo.raw
	mv -f discovery.raw discoverychannel.raw
	mv -f discoveryplus1.raw discoverychanplus1.raw
	mv -f disneychnl.raw disneychannel.raw
	mv -f disneychnlplus1.raw disneychannelplus1.raw
	mv -f foxnews.raw foxnewschannel
	mv -f ginxesportstv.raw ginx.raw
	mv -f historyplus1hour.raw historyplus1.raw
	mv -f homeandhealthplus.raw homeandhealthplus1.raw
	mv -f horrorchplus1.raw horrorchannelplus1.raw
	mv -f lfctv.raw liverpoolfctv.raw
	mv -f motorstvuk.raw motorstv.raw
	mv -f natgeo.raw nationalgeographic.raw
	mv -f natgeoplus1hr.raw nationalgeographicplus1.raw
	mv -f ndtv24x7.raw ndtvgoodtimes.raw
	mv -f nickjr.raw nickjunior.raw
	mv -f nickjr2.raw nickjr2.raw
	mv -f nickelodeonplus1.raw nickplus1.raw
	mv -f nollywood.raw nollywoodmovies.raw
	mv -f rishtey.raw rishteyeurope.raw
	mv -f rte2.raw rtetwo.raw
	mv -f skyaction.raw skyactionandadventure.raw
	mv -f skydramarom.raw skydramaandromance.raw
	mv -f skypremplus1.raw skypremiere1hr.raw
	mv -f skyspnewshq.raw skysportsnewshq.raw
	mv -f sonytv.raw sonytvasia.raw
	mv -f tcm.raw turnerclassicmovies.raw
	mv -f trueent.raw trueentertainment.raw
	mv -f tv5monde.raw tv5.raw
	mv -f universal.raw universalchannel.raw
	mv -f universalplus1.raw universalchannelplus1.raw
# remove icons for non-existant channels on VM
	rm -f 3e*
	rm -f aa* ab* ah* ai* ak* ala* am* ari* aryq* atn*
	rm -f bel* ben* bes* bl* br*
	rm -f cap* cc* channelaka* channel44* channeli
	rm -f chelsea* chi* chstv* cnc* crimeplusinvplus1*
	rm -f dmp* dun* eir* em* ew*
	rm -f fa* fk* foodnetwrkplus1* front*
	rm -f geo* gl* gos* gr*
	rm -f he* hid* hig* hil* hoc* hol* hor*
	rm -f idealextra* insp* iq* ir* isl* itvbo* itve*
	rm -f jml* keep* kic* kix.raw kixplus1* ktv*
	rm -f lifetimeplus1* love*
	rm -f madan* mov4* mta* mtvmusicplus1*
	rm -f mtvplus1* mychl*
	rm -f news18* noor* now* ntv* o*
	rm -f pav* pcne* pea* pickplus1*
	rm -f popplus1* prop* psy* ptc* ptv*
	rm -f ret* reve* rtej* rten* rteoneplus1* rus*
	rm -f sa* sc* show* si* skyat*
	rm -f sky1plus1* sonl* sonychnlplus1*
	rm -f sonymovies* starut* starz*
	rm -f tak* tal* tbn* thed* them* thev* tim*
	rm -f tinypoplus1* tlcplus2* travelchplus1* tri*
	rm -f truechrstmsplus1* truecr* truemoviesplus1*
	rm -f trutvplus1* tv3* tv99* tvc* tvo* tvw*
	rm -f umm* utv.* utvi*
	rm -f vch* ven* voxa*
	rm -f wordnetwork* your*
fi

# common for sat and cable
ln -sf bbcredbutton.raw bbcredbutton1.raw
ln -sf skydisney.raw skypixar.raw
for p in 1 2 3 4 5 6 7 8 9; do
	ln -sf skysportsactive.raw skysportsactive$p.raw
done

for p in 1 2 3 4 5 6; do
	ln -sf btsportextra.raw btsportextra$p.raw
done
