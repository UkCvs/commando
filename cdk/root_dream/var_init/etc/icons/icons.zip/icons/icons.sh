﻿#!/bin/sh

for p in \
	"BBC One CI" \
	"BBC One E Mid" \
	"BBC One East E" \
	"BBC One East W" \
	"BBC One N West" \
	"BBC One NE&C" \
	"BBC One Oxford" \
	"BBC One S East" \
	"BBC One S West" \
	"BBC One South" \
	"BBC One W Mid" \
	"BBC One Yk&Li" \
	"BBC One Yorks" \
; do ln -sf "BBC1.raw" "$p.raw"
done

for p in \
	"ITV Anglia East" \
	"ITV Anglia West" \
	"ITV Border Scotland" \
	"ITV Central East" \
	"ITV Central West" \
	"ITV Channel Isles" \
	"ITV Granada" \
	"ITV London" \
	"ITV Meridian North" \
	"ITV Meridian SE" \
	"ITV Meridian South" \
	"ITV Tyne Tees" \
	"ITV West" \
	"ITV West Country" \
	"ITV Yorkshire East" \
	"ITV Yorkshire West" \
; do ln -sf "ITV.raw" "$p.raw"
done

for p in \
	"ITV +1 Anglia" \
	"ITV +1 Central" \
	"ITV +1 Granada" \
	"ITV +1 London" \
	"ITV +1 Meridian SE" \
	"ITV +1 Tyne Tees" \
	"ITV +1 Wales" \
	"ITV +1 West" \
	"ITV +1 West Country" \
	"ITV +1 Yorkshire" \
; do ln -sf "ITV +1.raw" "$p.raw"
done

for p in \
	"STV Edinburgh" \
	"STV Glasgow" \
	"STV Grampian" \
	"STV North East" \
	"STV Scottish East" \
	"STV Scottish West" \
; do ln -sf "STV.raw" "$p.raw"
done
