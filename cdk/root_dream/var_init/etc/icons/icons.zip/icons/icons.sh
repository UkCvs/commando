﻿#!/bin/sh

for p in \
	"CI" \
	"E Mid" \
	"East E" \
	"East W" \
	"N West" \
	"NE&C" \
	"Oxford" \
	"S East" \
	"S West" \
	"South" \
	"W Mid" \
	"West" \
	"Yk&Li" \
	"Yorks" \
; do ln -sf "BBC1.raw" "BBC One $p.raw"
done

for p in \
	"Anglia East" \
	"Anglia West" \
	"Border Scotland" \
	"Central East" \
	"Central West" \
	"Channel Isles" \
	"Granada" \
	"London" \
	"Meridian North" \
	"Meridian SE" \
	"Meridian South" \
	"Tyne Tees" \
	"West" \
	"West Country" \
	"Yorkshire East" \
	"Yorkshire West" \
; do ln -sf "ITV.raw" "ITV $p.raw"
done

for p in \
	"Anglia" \
	"Central" \
	"Granada" \
	"London" \
	"Meridian SE" \
	"Tyne Tees" \
	"Wales" \
	"West" \
	"West Country" \
	"Yorkshire" \
; do ln -sf "ITV +1.raw" "ITV +1 $p.raw"
done

for p in \
	"Edinburgh" \
	"Glasgow" \
	"Grampian" \
	"North East" \
	"Scottish East" \
	"Scottish West" \
; do ln -sf "STV.raw" "STV $p.raw"
done
